import structures as AST


def addToClass(cls):

    def decorator(func):
        setattr(cls, func.__name__, func)
        return func
    return decorator


_print = print


def print(indent, *args, **kwargs):
    _print("|  " * indent + " ".join(str(x) for x in args), **kwargs)


def print_value(value, indent=0):
    if isinstance(value, AST.Node):
        value.print_tree(indent)
    else:
        print(indent, value)


class TreePrinter:

    @addToClass(AST.InstructionsList)
    def print_tree(self, indent=0):
        for instruction in self.instructions:
            instruction.print_tree(indent)

    @addToClass(AST.Assignment)
    def print_tree(self, indent=0):
        print(indent, self.assignment)
        print(indent + 1, self.id)
        print_value(self.expression, indent + 1)

    @addToClass(AST.FuncCall)
    def print_tree(self, indent=0):
        print(indent, self.name)
        print_value(self.params, indent + 1)

    @addToClass(AST.Matrix)
    def print_tree(self, indent=0):
        print(indent, "MATRIX")
        for row in self.rows:
            row.print_tree(indent + 1)

    @addToClass(AST.MatrixRow)
    def print_tree(self, indent=0):
        print(indent, "VECTOR")
        for item in self.items:
            print_value(item, indent + 1)

    @addToClass(AST.IndicesAssignment)
    def print_tree(self, indent=0):
        print(indent, "=")
        print(indent + 1, "REF")
        print(indent + 2, self.id)
        for item in self.items:
            print(indent + 2, item)
        print(indent + 1, self.value)

    @addToClass(AST.MatrixOperation)
    def print_tree(self, indent=0):
        print(indent, self.operator)
        self.left.print_tree(indent + 1)
        self.right.print_tree(indent + 1)

    @addToClass(AST.Variable)
    def print_tree(self, indent=0):
        if self.inverted:
            print(indent, "-" + self.id)
        else:
            print(indent, self.id)

    @addToClass(AST.TransposeOperation)
    def print_tree(self, indent=0):
        print(indent, "TRANSPOSE")
        print_value(self.value, indent + 1)

    @addToClass(AST.ForLoop)
    def print_tree(self, indent=0):
        print(indent, "FOR")
        print_value(self.enumeration.variable, indent + 1)
        self.enumeration.print_tree(indent + 1)
        self.instructions.print_tree(indent + 1)

    @addToClass(AST.Enumeration)
    def print_tree(self, indent=0):
        self.range.print_tree(indent)

    @addToClass(AST.Range)
    def print_tree(self, indent=0):
        print(indent, "RANGE")
        print_value(self.left, indent + 1)
        print_value(self.right, indent + 1)

    @addToClass(AST.PrintInstruction)
    def print_tree(self, indent=0):
        print(indent, "PRINT")
        for value in self.values:
            print_value(value, indent + 1)

    @addToClass(AST.WhileLoop)
    def print_tree(self, indent=0):
        print(indent, "WHILE")
        self.condition.print_tree(indent + 1)
        self.instructions.print_tree(indent + 1)

    @addToClass(AST.LogicalOperation)
    def print_tree(self, indent=0):
        print(indent, self.operator)
        print_value(self.left, indent + 1)
        print_value(self.right, indent + 1)

    @addToClass(AST.IfCondition)
    def print_tree(self, indent=0):
        print(indent, "IF")
        self.condition.print_tree(indent + 1)
        print(indent, "THEN")
        self.instruction.print_tree(indent + 1)
        print(indent, "ELSE")
        self.else_branch.print_tree(indent + 1)

    @addToClass(AST.BinaryOperation)
    def print_tree(self, indent=0):
        print(indent, self.operator)
        print_value(self.left, indent + 1)
        print_value(self.right, indent + 1)
