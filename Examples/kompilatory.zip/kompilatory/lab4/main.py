import sys

from Mparser import parser
from scanner import lexer
from TypeChecker import TypeChecker

file = open(sys.argv[1], "r")

text = file.read()
tokens = parser.parse(text, lexer=lexer)
checker = TypeChecker()
checker.visit(tokens)

if checker.any_errors():
    for error in checker.get_errors():
        print(error)
else:
    print(tokens)
