import sys

import ply.lex as lex


class Scanner:

    tokens = [
        "DOTADD",
        "DOTSUB",
        "DOTMUL",
        "DOTDIV",

        "ADDASSIGN",
        "SUBASSIGN",
        "MULASSIGN",
        "DIVASSIGN",

        "LEQ",
        "GEQ",
        "NEQ",
        "EQ",

        "ID",
        "INTNUM",
        "FLOATNUM",

        "COMMENT"
    ]

    t_DOTADD = r'\.\+'
    t_DOTSUB = r'\.-'
    t_DOTMUL = r'\.\*'
    t_DOTDIV = r'\.\/'

    t_ADDASSIGN = r'\+='
    t_SUBASSIGN = r'-='
    t_MULASSIGN = r'\*='
    t_DIVASSIGN = r'\/='

    t_LEQ = r'<='
    t_GEQ = r'>='
    t_NEQ = r'!='
    t_EQ = r'=='

    # TODO: could be r'\#.*\n*', but counting new lines
    #       should be implemented as a function then
    t_ignore_COMMENT = r'\#.*'

    t_ignore = " \t"

    reserved = {
        "if": "IF",
        "else": "ELSE",
        "for": "FOR",
        "while": "WHILE",
        "break": "BREAK",
        "continue": "CONTINUE",
        "return": "RETURN",
        "eye": "EYE",
        "zeros": "ZEROS",
        "ones": "ONES",
        "print": "PRINT"
    }

    literals = ['+', '-', '*', '/', '=', '<', '>',
                '(', ')', '[', ']', '{', '}', '\'', ',', ';', ':']

    def t_ID(self, t):
        r'[A-Za-z_]\w*'
        t.type = self.reserved.get(t.value, "ID")
        return t

    def t_FLOATNUM(self, t):
        r'\d+\.\d+'
        t.value = float(t.value)
        return t

    def t_INTNUM(self, t):
        r'\d+'
        t.value = int(t.value)
        return t

    def t_NEWLINE(self, t):
        r'\n+'
        t.lexer.lineno += len(t.value)
        self.newline_pos[t.lexer.lineno] = t.lexer.lexpos - 1

    def __init__(self):
        self.newline_pos = {}
        self.tokens += list(self.reserved.values())

    def build(self, **kwargs):
        self.lexer = lex.lex(module=self, **kwargs)

    def input(self, text):
        self.lexer.input(text)

    def token(self):
        while True:
            tok = self.lexer.token()
            if tok is None:
                return
            tok.__dict__["line_lexpos"] = tok.lexpos - \
                self.newline_pos.get(tok.lineno, -1)
            return "({lineno},{line_lexpos}): {type}({value})".format(**vars(tok))

    def t_error(self, t):
        sys.stderr.write(
            "Illegal character '{}' in line #{}\n".format(t.value[0], t.lineno))
        t.lexer.skip(1)
