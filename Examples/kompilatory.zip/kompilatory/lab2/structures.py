import attr

from functools import wraps


@attr.s
class InstructionsList:
    instructions = attr.ib(default=list)

    def __add__(self, other):
        self.instructions += other.instructions
        return self


@attr.s
class Assignment:
    id = attr.ib()
    assignment = attr.ib()
    expression = attr.ib()


@attr.s
class Matrix:
    rows = attr.ib()


@attr.s
class MatrixRow:
    items = attr.ib()

    def __add__(self, other):
        self.items += other
        return self


@attr.s
class FuncCall:
    name = attr.ib()
    params = attr.ib()


@attr.s
class Variable:
    id = attr.ib()
    inverted = attr.ib(default=False)

    def __neg__(self):
        self.inverted = not self.inverted
        return self


@attr.s
class IndicesAssignment:
    id = attr.ib()
    items = attr.ib()
    value = attr.ib()

    def __add__(self, newitems):
        self.range += newitems
        return self


@attr.s
class BinaryOperation:
    operator = attr.ib()
    left = attr.ib()
    right = attr.ib()


@attr.s
class LogicalOperation:
    operator = attr.ib()
    left = attr.ib()
    right = attr.ib()


@attr.s
class MatrixOperation:
    operator = attr.ib()
    left = attr.ib()
    right = attr.ib()


@attr.s
class TransposeOperation:
    value = attr.ib()


@attr.s
class Range:
    left = attr.ib()
    right = attr.ib()


@attr.s
class PrintInstruction:
    values = attr.ib()


@attr.s
class ForLoop:
    enumeration = attr.ib()
    instructions = attr.ib()


@attr.s
class WhileLoop:
    condition = attr.ib()
    instructions = attr.ib()


@attr.s
class Enumeration:
    variable = attr.ib()
    range = attr.ib()


@attr.s
class IfCondition:
    condition = attr.ib()
    instruction = attr.ib()
    else_branch = attr.ib(default=None)
