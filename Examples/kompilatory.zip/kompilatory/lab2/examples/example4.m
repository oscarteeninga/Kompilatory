i = 2;
j = 2;
if (i == 2)
    if (j == 3)
        print i, j;
    else
        print "j != 1";
